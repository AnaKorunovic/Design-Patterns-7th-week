/* Client8.java
 * @autor  prof. dr Sinisa Vlajic,
 * Univerzitet u Beogradu
 * Fakultet organizacionih nauka 
 * Katedra za softversko inzenjerstvo
 * Laboratorija za softversko inzenjerstvo
 * 27.11.2017
 */

package ZFW1;

// ������� ZFW1: ������ ������� �� ����� ��� ����� ���� �� �� ������ ������: 
// Danas je lep dan.
// Sutra ce biti jos lepsi.
// Juce je bilo oblacno.
// ***************************
// Danas je lep dan. Sutra ce biti jos lepsi.
// Juce je bilo oblacno.

class Client8
{
    public static void main(String[] args) {
       FlyweightFactory ff = new FlyweightFactory(); 
       ff.dodajFlyweight(...);
       ff.dodajFlyweight("Sutra ce biti jos lepsi.","\n");
       ff.dodajFlyweight(...);
       ff.prikaziFlyweight();
       ...
       ff = new FlyweightFactory();
       ff.dodajFlyweight("Danas je lep dan."," ");
       ff.dodajFlyweight(...);
       ff.dodajFlyweight("Juce je bilo oblacno.","");
       ff.prikaziFlyweight();
    }
}


class FlyweightFactory   
{ Flyweight fw[];
  int flyweightCounter;

  FlyweightFactory(){fw = new Flyweight[30];flyweightCounter=0;}
  void dodajFlyweight(String sharedState, String unsharedState)
     {  boolean signal = false;
        for(int i = 0; i<flyweightCounter;i++)
                { if (fw[i].getState().equals(sharedState))
                     {   fw[flyweightCounter++] = fw[i];
                         signal = true; 
                         break; 
                     }
                }

            if (...) fw[flyweightCounter++] = new ConcreteFlyweight(...);
            fw[flyweightCounter++] = new UnsharedConcreteFlyweight(...);
      }
  
   void prikaziFlyweight()
    {   String poruka = "";
        for(int i=0;i<flyweightCounter;i++)  
           { poruka = poruka + fw[i].getState(); }
    	System.out.println(poruka);
    }
}
  


abstract class Flyweight 
{  abstract String getState();
}

class ConcreteFlyweight extends ... 
{ String sharedState;
  ConcreteFlyweight ( String sharedState1){sharedState = sharedState1;}
  
  @Override
  String getState(){return sharedState;}
  }

class UnsharedConcreteFlyweight  extends Flyweight 
{ String unsharedState;
  UnsharedConcreteFlyweight(String unsharedState1) {unsharedState = unsharedState1; }
  @Override
  public String getState(){return unsharedState;}
}


