/* UpravaFakulteta.java
 * @autor  prof. dr Sinisa Vlajic,
 * Univerzitet u Beogradu
 * Fakultet organizacionih nauka 
 * Katedra za softversko inzenjerstvo
 * Laboratorija za softversko inzenjerstvo
 * 27.11.2017
 */

package pfw11;

// Кориснички захтев PFW11: Управа Факултета је тражила од Јава тима да припреми своју понуду у следећа три различита облика:
// Ponuda Java tima.
// Autor: Lab. za softversko inzenjerstvo.
// Programski jezik: Java.
// SUBP:MySQL.
// *******************************
// Ponuda Java tima.	Autor: Lab. za softversko inzenjerstvo.
// Programski jezik: Java. SUBP:MySQL.
// *******************************
// Ponuda Java tima.
//	Autor: Lab. za softversko inzenjerstvo.
//		Programski jezik: Java.
//		SUBP:MySQL.
// *******************************
// Шеф Лабораторије за софтверско инжењерство је тражио од Јава тима да елементе понуде чува на једном месту, 
// како се не би десила редуданса истих елемената понуде у различитим захтеваним облицима понуде.

class UpravaFakulteta
{ static SILAB sil;
  public static void main(String args[])
	{  sil = new JavaTimPonuda();
	   sil.kreirajProgramskiJezik();
	   sil.kreirajSUBP();
	   sil.kreirajPonudu1(); 
	   sil.kreirajPonudu2();
	   sil.kreirajPonudu3();
           sil.prikaziPonude();
	}
}

class Ponuda {String ponuda;}

abstract class SILAB
{ ProgramskiJezik  pj;  SUBP subp;  Ponuda pon;
  abstract void kreirajProgramskiJezik();
  abstract void kreirajSUBP();
  abstract void kreirajPonudu1();
  abstract void kreirajPonudu2();
  abstract void kreirajPonudu3();
  abstract void prikaziPonude();
}


class JavaTimPonuda extends SILAB  // Client
{ FabrikaElemenataPonude fep;
  
  JavaTimPonuda()
    { fep = new FabrikaElemenataPonude();pon = new Ponuda();
    }
      @Override
      void kreirajProgramskiJezik(){pj = new Java();}
      @Override
      void kreirajSUBP() {subp = new MySQL();}
     
  @Override
  void kreirajPonudu1()
     { 
       fep.dodajElementPonude("Ponuda Java tima.","\n");
       fep.dodajElementPonude("Autor: Lab. za softversko inzenjerstvo.","\n");
       fep.dodajElementPonude("Programski jezik: " + pj.vratiProgramskiJezik() + ".","\n");
       fep.dodajElementPonude("SUBP:" + subp.vratiSUBP() + ".","\n"); 
       fep.dodajElementPonude("*******************************","\n"); 
       
     }
  
  @Override
  void kreirajPonudu2()
     { 
       fep.dodajElementPonude("Ponuda Java tima.","\t");
       fep.dodajElementPonude("Autor: Lab. za softversko inzenjerstvo.","\n");
       fep.dodajElementPonude("Programski jezik: " + pj.vratiProgramskiJezik() + ". ","");
       fep.dodajElementPonude("SUBP:" + subp.vratiSUBP() + ".","\n"); 
       fep.dodajElementPonude("*******************************","\n");
     }
  
  @Override
  void kreirajPonudu3()
     { 
       fep.dodajElementPonude("Ponuda Java tima.","\n\t");
       fep.dodajElementPonude("Autor: Lab. za softversko inzenjerstvo.","\n\t\t");
       fep.dodajElementPonude("Programski jezik: " + pj.vratiProgramskiJezik() + ".","\n\t\t");
       fep.dodajElementPonude("SUBP:" + subp.vratiSUBP() + ".","");             
     }
  
@Override
void prikaziPonude()
    {  pon.ponuda = "";
        for(int i=0;i<fep.vratiBrojElemenataPonude();i++)  
           { pon.ponuda = pon.ponuda + fep.ep[i].vratiStanje(); }
    	System.out.println(pon.ponuda);
           
     }
 }

interface ProgramskiJezik
{String vratiProgramskiJezik();}

class Java implements ProgramskiJezik
{ @Override
  public String vratiProgramskiJezik(){return "Java";}}

interface SUBP
{String vratiSUBP();}

class MySQL implements SUBP
{ @Override
  public String vratiSUBP(){return "MySQL";}}

class FabrikaElemenataPonude   // FlyweightFactory
{ ElementPonude ep[];
  int brojElemenata;

  FabrikaElemenataPonude(){ep = new ElementPonude[30];brojElemenata=0;}
  void dodajElementPonude(String deljeniElementPonude, String nedeljeniElementPonude)
     {  boolean signal = false;
        for(int i = 0; i<brojElemenata;i++)
                { if (ep[i].vratiStanje().equals(deljeniElementPonude))
                     {   ep[brojElemenata++] = ep[i];
                         signal = true; 
                         break; 
                     }
                }

            if (!signal) ep[brojElemenata++] = new DeljeniElementPonude(deljeniElementPonude);
            ep[brojElemenata++] = new NedeljeniElementPonude(nedeljeniElementPonude);
      }
  int vratiBrojElemenataPonude(){return brojElemenata;}
  void postaviBrojElemenataPonude(int brojElemenata1){brojElemenata=brojElemenata1;}
}

abstract class ElementPonude // Flyweight
{  abstract String vratiStanje();
}

class DeljeniElementPonude extends ElementPonude // ConcreteFlyweight
{ String deljenoStanje;
  DeljeniElementPonude ( String deljenoStanje1){deljenoStanje = deljenoStanje1;}
  
  @Override
  String vratiStanje(){return deljenoStanje;}
  }

class NedeljeniElementPonude  extends ElementPonude // UnsharedConcreteFlyweight
{ String nedeljenoStanje;
  NedeljeniElementPonude(String nedeljenoStanje1) {nedeljenoStanje = nedeljenoStanje1; }
  @Override
  public String vratiStanje(){return nedeljenoStanje;}
}


